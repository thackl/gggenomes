library(testthat)
library(gggenomes)

test_check("gggenomes")
